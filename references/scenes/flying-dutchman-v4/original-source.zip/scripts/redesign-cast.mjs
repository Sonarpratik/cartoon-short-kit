import {readFile,writeFile,mkdir,copyFile,cp} from 'node:fs/promises';
const root=new URL('../../../',import.meta.url),project=new URL('../',import.meta.url);
const current=JSON.parse(await readFile(new URL('characters/cast.json',project),'utf8'));
if(!current.characters[0].id.endsWith('-v2'))await cp(new URL('characters/',project),new URL('characters-v1/',project),{recursive:true,errorOnExist:true,force:false});
const base={project:'flying-dutchman-v2',coat:false,skin:'#faf9f5',light:-2.2};
const characters=[
 {...base,id:'dutchman-george-v2',identity:'dutchman-george',name:'George · swept brown hair, cadet blues',seed:18,build:'kid',jacket:'#254b78',pants:'#e2d8bc',boots:'#323144',hair:'#6a432e',hairStyle:'sidepart',outfit:{hat:'hair',buttons:'#d8b060',belt:'#eee4c9',sash:'#bb744f'}},
 {...base,id:'dutchman-lookout-v2',identity:'dutchman-lookout',name:'Henry · ginger hair and full beard',seed:24,build:'stout',jacket:'#ded2ae',pants:'#3c596a',boots:'#635044',hair:'#9e542f',hairStyle:'bob',outfit:{hat:'hair',buttons:'#514b42',beard:'#8e482c',moustache:'#8e482c'}},
 {...base,id:'dutchman-officer-v2',identity:'dutchman-officer',name:'Watch officer · silver hair and moustache',seed:31,jacket:'#243d3e',pants:'#3b3a46',boots:'#292933',hair:'#b8bab0',hairStyle:'receding',outfit:{hat:'hair',buttons:'#dfb65d',belt:'#aa8546',moustache:'#a2a79d',sash:'#b8644d'}},
 {...base,id:'dutchman-midshipman-v2',identity:'dutchman-midshipman',name:'Midshipman · dark spiky hair, short moustache',seed:8,jacket:'#944f3d',pants:'#a9b2a3',boots:'#383b46',hair:'#312b35',hairStyle:'spiky',accessory:'investigator',outfit:{hat:'hair',buttons:'#e1c5a1',moustache:'#3b2c31'}}
];
const path=new URL('references/characters/cast.json',root),catalog=JSON.parse(await readFile(path,'utf8'));
for(const c of characters){const index=catalog.characters.findIndex(d=>d.id===c.id);if(index<0)catalog.characters.push(c);else catalog.characters[index]=c;}
await writeFile(path,JSON.stringify(catalog,null,2)+'\n');
await writeFile(new URL('characters/cast.json',project),JSON.stringify({schemaVersion:1,characters},null,2)+'\n');
const reference=new URL('references/characters/flying-dutchman-v2/',root);await mkdir(new URL('engine/',reference),{recursive:true});
await writeFile(new URL('cast-design.json',reference),JSON.stringify({schemaVersion:1,characters},null,2)+'\n');
for(const name of ['character-rig.ts','toon.ts','style.ts','face-style.ts','director.ts','hair-3d.ts','angle-designs.ts']){
 await copyFile(new URL('templates/bridge/'+name,root),new URL('engine/'+name,reference));
 await copyFile(new URL('templates/bridge/'+name,root),new URL('characters/'+name,project));
}
const server=new URL('preview-characters.mjs',root);let source=await readFile(server,'utf8');source=source.replace("'sash','moustache','skin'","'sash','moustache','beard','skin'");await writeFile(server,source);
console.log('Saved four distinct v2 characters; original cast and renderer archived.');
