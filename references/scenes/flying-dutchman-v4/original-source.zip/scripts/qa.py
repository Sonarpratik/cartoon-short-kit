from pathlib import Path
import json,subprocess,re,hashlib
import numpy as np
from PIL import Image,ImageDraw
import imageio_ffmpeg
root=Path(__file__).resolve().parents[1];ff=imageio_ffmpeg.get_ffmpeg_exe();video=root/'out/The_Prince_and_the_Ghost_Ship.mp4';out=root/'out/qa';out.mkdir(exist_ok=True)
def run(args):return subprocess.run([ff,*args],capture_output=True,check=True)
metadata=run(['-hide_banner','-i',str(video),'-f','null','-']).stderr.decode(errors='replace')
(out/'metadata.txt').write_text(metadata)
report={'video':video.name,'specs_verified':all(s in metadata for s in ['1080x1920','30 fps','h264','aac']),'decoded_frames':0,'black_frames':[],'frozen_spans':[]}
proc=subprocess.Popen([ff,'-v','error','-i',str(video),'-vf','scale=180:320','-f','rawvideo','-pix_fmt','rgb24','-'],stdout=subprocess.PIPE)
prev=None;held=0;start=0;diffs=[];means=[];thumbs=[];i=0
while True:
 data=proc.stdout.read(180*320*3)
 if not data:break
 if len(data)!=180*320*3:raise ValueError('Incomplete decoded frame')
 im=np.frombuffer(data,np.uint8).reshape(320,180,3);mean=float((im@np.array([.2126,.7152,.0722])).mean()/255);means.append(mean)
 if mean<.035:report['black_frames'].append(i)
 if prev is not None:
  diff=float(np.abs(im.astype(np.int16)-prev).mean());diffs.append(diff)
  if diff<.02:
   if held==0:start=i-1
   held+=1
  else:
   if held>=12:report['frozen_spans'].append([start,i-1])
   held=0
 if i%60==0:thumbs.append((i,Image.fromarray(im.copy())))
 prev=im.astype(np.int16);i+=1
proc.wait();report['decoded_frames']=i
if held>=12:report['frozen_spans'].append([start,i-1])
report['mean_frame_difference']=float(np.mean(diffs));report['mean_luminance_range']=[min(means),max(means)]
report['intentional_quiet_ocean_ranges']=[[414,504],[855,926]]
report['frozen_spans_outside_quiet_ocean']=[span for span in report['frozen_spans'] if not any(span[0]>=a and span[1]<=b for a,b in report['intentional_quiet_ocean_ranges'])]
for scene in ['S01','S02','S03','S04','S05','S06']:
 manifest=json.loads((root/f'frames/{scene}/manifest.json').read_text());files=list((root/f'frames/{scene}').glob('f*.jpg'));assert len(files)==manifest['count']
report['scene_frame_manifests']='Complete, 1550 total frames'
sheet=Image.new('RGB',(6*180,5*350),'#101c29');p=ImageDraw.Draw(sheet)
for j,(f,im) in enumerate(thumbs):
 x=j%6*180;y=j//6*350;sheet.paste(im,(x,y+25));p.text((x+5,y+6),f'{f/30:.1f}s / f{f}',fill='#e6d7b8')
sheet.save(root/'out/contact-sheet.jpg',quality=93)
audio=run(['-v','error','-i',str(video),'-vn','-ar','48000','-ac','1','-f','f32le','-']).stdout
decoded=np.frombuffer(audio,np.float32);report['audio_duration_seconds']=len(decoded)/48000;report['decoded_audio_peak']=float(np.max(np.abs(decoded)))
from scipy.io import wavfile
sr,mix=wavfile.read(root/'public/mix.wav');reference=mix.astype(np.float32)/32768;n=min(len(decoded),len(reference));report['audio_matches_mix_correlation']=float(np.corrcoef(decoded[:n],reference[:n])[0,1])
loudness=run(['-hide_banner','-i',str(video),'-vn','-af','ebur128=peak=true','-f','null','-']).stderr.decode(errors='replace');(out/'loudness.txt').write_text(loudness[loudness.rfind('Summary:'):])
report['passed']=report['specs_verified'] and i==1550 and not report['black_frames'] and not report['frozen_spans_outside_quiet_ocean'] and report['audio_matches_mix_correlation']>.99 and report['decoded_audio_peak']<1
(out/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if not report['passed']:raise SystemExit('QA requires inspection')
