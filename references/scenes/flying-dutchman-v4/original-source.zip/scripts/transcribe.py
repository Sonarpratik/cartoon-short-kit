from pathlib import Path
import json, subprocess, wave
import imageio_ffmpeg
import numpy as np
from faster_whisper import WhisperModel

root=Path(__file__).resolve().parents[1]
ffmpeg=imageio_ffmpeg.get_ffmpeg_exe()
subprocess.run([ffmpeg,'-y','-v','error','-i',str(root/'public/narration.mp3'),'-ar','16000','-ac','1',str(root/'work/voice.wav')],check=True)
with wave.open(str(root/'work/voice.wav')) as f: duration=f.getnframes()/f.getframerate()
model=WhisperModel('small.en',device='cpu',compute_type='int8',local_files_only=True,cpu_threads=6)
with wave.open(str(root/'work/voice.wav')) as f: audio=np.frombuffer(f.readframes(f.getnframes()),dtype=np.int16).astype(np.float32)/32768
segments,info=model.transcribe(audio,word_timestamps=True,beam_size=5)
data={'duration':duration,'segments':[],'words':[]}
for s in segments:
 print(f'{s.start:.2f}–{s.end:.2f}: {s.text}',flush=True)
 data['segments'].append({'start':s.start,'end':s.end,'text':s.text})
 data['words'] += [{'start':w.start,'end':w.end,'word':w.word.strip()} for w in s.words]
(root/'work/timing.json').write_text(json.dumps(data,indent=2))
print('Duration:',duration,flush=True)
