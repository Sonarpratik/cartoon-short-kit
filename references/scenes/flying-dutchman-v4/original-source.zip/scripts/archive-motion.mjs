import {cp,mkdir,readFile,writeFile} from 'node:fs/promises';
await mkdir('work/motion-before',{recursive:true});
for(const folder of ['characters','src'])await cp(folder,'work/motion-before/'+folder,{recursive:true});
console.log('Preserved pre-correction renderer and scene source.');
