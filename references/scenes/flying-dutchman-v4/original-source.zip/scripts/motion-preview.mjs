import {chromium} from 'playwright';import {mkdir,writeFile} from 'node:fs/promises';import {spawn,execFileSync} from 'node:child_process';import {once} from 'node:events';
const ff=execFileSync('python',['-c','import imageio_ffmpeg;print(imageio_ffmpeg.get_ffmpeg_exe())'],{encoding:'utf8'}).trim();
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',args:['--disable-accelerated-2d-canvas']});
function encode(args){const p=spawn(ff,['-y','-hide_banner','-loglevel','error','-f','image2pipe','-vcodec','mjpeg','-framerate','30','-i','pipe:0',...args],{stdio:['pipe','ignore','inherit']});const done=new Promise((resolve,reject)=>p.on('close',code=>code===0?resolve():reject(Error('Encoder '+code))));return {p,done};}
try{
 await mkdir('review/motion-v3',{recursive:true});const page=await browser.newPage();await page.goto('http://127.0.0.1:8791/?scale=.6666666666666666');await page.waitForFunction(()=>window.ready);
 await page.evaluate(async()=>{
  const before=await import('/work/motion-before/characters/character-rig.ts'),after=await import('/characters/character-rig.ts'),{midshipmanMotion}=await import('/src/locomotion.ts'),oldCast=await fetch('/work/motion-before/characters/cast.json').then(r=>r.json()),newCast=await fetch('/characters/cast.json').then(r=>r.json());
  const canvas=document.createElement('canvas');canvas.width=1280;canvas.height=960;const g=canvas.getContext('2d');
  window.motionCompare=(f)=>{const elapsed=f/30-.6,t=23.5+elapsed,m=midshipmanMotion(t),oldDistance=Math.max(0,Math.min(4.2,elapsed*.65)),walking=elapsed>=0&&elapsed<6.46;g.fillStyle='#e8e3d7';g.fillRect(0,0,1280,960);
   for(let row=0;row<2;row++){const y=row*480;g.fillStyle=row?'#dce7dd':'#e9ddd8';g.fillRect(0,y,1280,480);g.fillStyle='#2e3440';g.font='bold 27px sans-serif';g.fillText(row?'AFTER · feet follow travel, steady body':'BEFORE · independent foot speed, oversized hair',28,y+42);g.strokeStyle='#a1a79d';g.lineWidth=2;for(let x=50;x<1280;x+=150){g.beginPath();g.moveTo(x,y+420);g.lineTo(x,y+455);g.stroke();}g.beginPath();g.moveTo(0,y+420);g.lineTo(1280,y+420);g.stroke();
    const distance=row?m.distance:oldDistance,x=120+distance*150;g.save();g.translate(x-300*.375,y+420-975*.375);g.scale(.375,.375);
    (row?after:before).drawCharacter(g,row?newCast.characters[3]:oldCast.characters[3],row?{yaw:90,time:t,action:walking?'walk':'idle',gaitPhase:m.phase,locomotionBlend:m.blend,micro:true,expression:'neutral'}:{yaw:270,time:t,action:walking?'walk':'idle',micro:true,expression:'neutral'});g.restore();
   }return canvas.toDataURL('image/jpeg',.92).split(',')[1];};
 });
 const a=encode(['-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart','review/motion-v3/walk-before-after.mp4']);
 for(let f=0;f<240;f++){const bytes=Buffer.from(await page.evaluate(f=>window.motionCompare(f),f),'base64');if([36,57,78,99,120,141,162,183].includes(f))await writeFile(`review/motion-v3/compare-${f}.jpg`,bytes);if(!a.p.stdin.write(bytes))await once(a.p.stdin,'drain');}a.p.stdin.end();await a.done;console.log('Before/after comparison complete');
 const b=encode(['-ss','23','-i','public/mix.wav','-map','0:v:0','-map','1:a:0','-t','8.5','-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','review/motion-v3/scene-motion-preview.mp4']);
 for(let f=690;f<945;f++){const bytes=Buffer.from(await page.evaluate(f=>window.captureFrame(f),f),'base64');if([705,750,780,810,840,870,900].includes(f))await writeFile(`review/motion-v3/scene-${f}.jpg`,bytes);if(!b.p.stdin.write(bytes))await once(b.p.stdin,'drain');if(f%60===0)console.log('Scene preview frame '+f);}b.p.stdin.end();await b.done;console.log('Corrected scene motion preview complete');
}finally{await browser.close();}
