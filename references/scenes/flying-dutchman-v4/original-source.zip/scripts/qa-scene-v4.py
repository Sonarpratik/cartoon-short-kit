from pathlib import Path
import subprocess,json
import numpy as np
from scipy.io import wavfile
from PIL import Image,ImageDraw
import imageio_ffmpeg
root=Path(__file__).resolve().parents[1];out=root/'review/scene-v4';ff=imageio_ffmpeg.get_ffmpeg_exe();video=out/'The_Prince_and_the_Ghost_Ship_scene_review.mp4'
raw=subprocess.run([ff,'-v','error','-i',str(video),'-vf','scale=144:256','-pix_fmt','rgb24','-f','rawvideo','-'],capture_output=True,check=True).stdout
frames=np.frombuffer(raw,np.uint8).reshape(-1,256,144,3);luma=frames@np.array([.2126,.7152,.0722]);black=np.flatnonzero(luma.mean((1,2))<5).tolist();diff=np.abs(np.diff(frames.astype(np.int16),axis=0)).mean((1,2,3));holds=[];a=None
for i,d in enumerate(diff):
 if d<.02 and a is None:a=i
 elif d>=.02 and a is not None:
  if i-a>=12:holds.append([a,i])
  a=None
sheet=Image.new('RGB',(6*180,5*344),'#101b27');p=ImageDraw.Draw(sheet)
for j,f in enumerate(range(0,len(frames),60)):
 im=Image.fromarray(frames[f]).resize((180,320));x=j%6*180;y=j//6*344;sheet.paste(im,(x,y+24));p.text((x+4,y+5),f'{f/30:.1f}s',fill='#e9d7b6')
sheet.save(out/'contact-sheet.jpg',quality=94)
audio=subprocess.run([ff,'-v','error','-i',str(video),'-vn','-ac','1','-ar','48000','-f','f32le','-'],capture_output=True,check=True).stdout
audio=np.frombuffer(audio,np.float32);_,ref=wavfile.read(root/'public/mix.wav');n=min(len(audio),len(ref));correlation=float(np.corrcoef(audio[:n],ref[:n])[0,1]);report={'frames':len(frames),'blackFrames':black,'unmovingSpansOver12Frames':holds,'audioMatchesMixCorrelation':correlation,'audioPeak':float(np.max(np.abs(audio))),'previewResolution':'720x1280','fps':30,'passed':len(frames)==1550 and not black and not holds and correlation>.99}
(out/'qa.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['passed']
