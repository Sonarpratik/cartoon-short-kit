import {chromium} from 'playwright';import assert from 'node:assert/strict';import {writeFile,mkdir} from 'node:fs/promises';
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',args:['--disable-accelerated-2d-canvas']});
try{const page=await browser.newPage();await page.goto('http://127.0.0.1:8791');await page.waitForFunction(()=>window.ready);
 const result=await page.evaluate(async()=>{
  const {walkCycle,relativeView,drawCharacter}=await import('/characters/character-rig.ts'),{midshipmanMotion}=await import('/src/locomotion.ts'),{CharacterPen}=await import('/characters/face-style.ts');
  let maxDrift=0,maxProjectionError=0,finite=true,checks=0;const scale=2.5/1000;
  for(let heading=0;heading<360;heading+=30){const h=heading*Math.PI/180;
   for(let t=24;t<29.4;t+=.01){const a=midshipmanMotion(t),b=midshipmanMotion(t+.001),ga=walkCycle(a.phase,350,.45,32),gb=walkCycle(b.phase,350,.45,32);
    for(let j=0;j<2;j++)if(ga.legs[j].stance&&gb.legs[j].stance){const x1=a.distance*Math.sin(h)+ga.legs[j].points[2][2]*scale*Math.sin(h),z1=a.distance*Math.cos(h)+ga.legs[j].points[2][2]*scale*Math.cos(h),x2=b.distance*Math.sin(h)+gb.legs[j].points[2][2]*scale*Math.sin(h),z2=b.distance*Math.cos(h)+gb.legs[j].points[2][2]*scale*Math.cos(h);maxDrift=Math.max(maxDrift,Math.hypot(x2-x1,z2-z1));checks++;}
   }
   for(let bearing=0;bearing<360;bearing+=30){const b=bearing*Math.PI/180,yaw=relativeView(heading,10*Math.sin(b),10*Math.cos(b))*Math.PI/180;maxProjectionError=Math.max(maxProjectionError,Math.abs(Math.sin(yaw)-(Math.sin(h)*Math.cos(b)-Math.cos(h)*Math.sin(b))));}
  }
  const canvas=document.createElement('canvas');canvas.width=600;canvas.height=1000;const g=canvas.getContext('2d'),original=CharacterPen.prototype.P;
  CharacterPen.prototype.P=function(x,y){const p=original.call(this,x,y);finite&&=p.every(Number.isFinite);return p;};
  const cast=window.debugWorld.actors.map(a=>a.design);let rendered=0;
  for(const d of cast)for(const yaw of [0,30,60,89,90,91,120,180,240,269,270,271,300,330])for(let i=0;i<8;i++){g.clearRect(0,0,600,1000);drawCharacter(g,d,{yaw,pitch:0,time:i/8,action:'walk',gaitPhase:i/8,locomotionBlend:1,micro:true});rendered++;}
  CharacterPen.prototype.P=original;
  const nearStart=midshipmanMotion(23.5+.0001),nearEnd=midshipmanMotion(29.96-.0001);
  const probes=[];for(const f of [705,750,780,810,840,870,899]){window.renderFrame(f);const a=window.debugWorld.actors[3];probes.push({frame:f,pitch:a.mesh.rotation.x,roll:a.mesh.rotation.z,phase:a.gaitPhase,blend:a.locomotionBlend,worldZ:a.mesh.position.z});}
  return {checks,maxStanceFootDriftMetres:maxDrift,maxCameraProjectionError:maxProjectionError,finiteCoordinates:finite,renderedPoses:rendered,startTravel:nearStart.distance,endRemainingTravel:4.2-nearEnd.distance,probes,oldCadenceExpectedSpeed:2*370*.45*2.5/1000*1.4,oldActualSpeed:.65};
 });
 assert(result.maxStanceFootDriftMetres<1e-8);assert(result.maxCameraProjectionError<1e-10);assert(result.finiteCoordinates);assert(result.startTravel<1e-8&&result.endRemainingTravel<1e-8);assert(result.probes.every(p=>Math.abs(p.pitch)<1e-10&&Math.abs(p.roll)<1e-10));await mkdir('review/motion-v3',{recursive:true});await writeFile('review/motion-v3/checks.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
}finally{await browser.close();}
