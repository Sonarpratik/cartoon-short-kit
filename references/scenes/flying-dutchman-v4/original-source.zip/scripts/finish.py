from pathlib import Path
import json,os,subprocess
import imageio_ffmpeg
root=Path(__file__).resolve().parents[1];folder=root/'frames/all';folder.mkdir(exist_ok=True)
for scene in ['S01','S02','S03','S04','S05','S06']:
 manifest=json.loads((root/f'frames/{scene}/manifest.json').read_text())
 for i in range(manifest['start'],manifest['end']):
  source=root/f'frames/{scene}/f{i:04}.jpg';target=folder/f'f{i:04}.jpg'
  if not target.exists():os.link(source,target)
assert len(list(folder.glob('f*.jpg')))==1550
ff=imageio_ffmpeg.get_ffmpeg_exe()
subprocess.run([ff,'-y','-hide_banner','-loglevel','warning','-framerate','30','-i',str(folder/'f%04d.jpg'),'-i',str(root/'public/mix.wav'),'-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart',str(root/'out/The_Prince_and_the_Ghost_Ship.mp4')],check=True)
report=json.loads((root/'out/render.json').read_text());report.update({'picture_duration':1550/30,'audio_duration':51.6440625,'final_encode':'All 1550 captured frames; no fractional-frame trim'})
(root/'out/render.json').write_text(json.dumps(report,indent=2));print('Encoded all 1550 frames.')
