from pathlib import Path
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parents[1]
sheet=Image.new('RGB',(1080,1320),'#101c29');p=ImageDraw.Draw(sheet)
for i,s in enumerate(['S01','S02','S03','S04','S05','S06']):
 files=sorted([f for f in (root/'review').glob(s+'-*.jpg') if f.stem.split('-')[-1].isdigit()],key=lambda f:int(f.stem.split('-')[-1]))
 row=Image.new('RGB',(810,520),'#101c29');d=ImageDraw.Draw(row)
 for j,f in enumerate(files):
  im=Image.open(f);im.thumbnail((260,465));row.paste(im,(j*270,30));d.text((j*270+5,8),f'{s} / frame {f.stem.split("-")[-1]}',fill='#efddba')
 row.save(root/f'review/{s}-review.jpg',quality=92)
 im=Image.open(files[1]);im.thumbnail((340,605));x=i%3*360;y=i//3*660;sheet.paste(im,(x,y+35));p.text((x+12,y+12),s,fill='#efddba')
sheet.save(root/'review/storyboard.jpg',quality=94)
