from pathlib import Path
import subprocess,re
from PIL import Image,ImageDraw
import imageio_ffmpeg
src=Path(r'C:\Users\admin\Downloads\vidssave.com Levels of Pirate Cannonballs 720P.mp4')
out=Path(__file__).resolve().parents[1]/'work/private-motion-study';out.mkdir(exist_ok=True)
ff=imageio_ffmpeg.get_ffmpeg_exe()
info=subprocess.run([ff,'-hide_banner','-i',str(src)],capture_output=True).stderr.decode(errors='replace');print(info[:1900])
subprocess.run([ff,'-y','-v','error','-i',str(src),'-vf','fps=1,scale=180:-1','-q:v','3',str(out/'f%03d.jpg')],check=True)
files=sorted(out.glob('f*.jpg'));w,h=Image.open(files[0]).size;sheet=Image.new('RGB',(w*10,(h+24)*((len(files)+9)//10)),'#101b27');p=ImageDraw.Draw(sheet)
for i,f in enumerate(files):x=i%10*w;y=i//10*(h+24);sheet.paste(Image.open(f),(x,y+24));p.text((x+4,y+4),str(i)+'s',fill='white')
sheet.save(out/'contact.jpg',quality=92);print('Study frames',len(files))
