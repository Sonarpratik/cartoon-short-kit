import {chromium} from 'playwright';
import {mkdir,writeFile,readFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {spawn,execFileSync} from 'node:child_process';
import {once} from 'node:events';
const ff=execFileSync('python',['-c','import imageio_ffmpeg;print(imageio_ffmpeg.get_ffmpeg_exe())'],{encoding:'utf8'}).trim();
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true,args:['--disable-accelerated-2d-canvas']});
async function files(dir){const result=[];for(const e of await readdir(dir,{withFileTypes:true})){const p=dir+'/'+e.name;if(e.isDirectory())result.push(...await files(p));else result.push(p);}return result;}
try{const page=await browser.newPage({viewport:{width:1080,height:1920}});const errors=[];page.on('pageerror',e=>{errors.push(e.message);console.error(e.message);});await page.goto('http://127.0.0.1:8791/?scale=1');await page.waitForFunction(()=>window.ready,{},{timeout:120000});const shots=await page.evaluate(()=>window.shots);await mkdir('out',{recursive:true});
 const hash=createHash('sha256');for(const file of [...await files('src'),...await files('characters')].sort()){hash.update(file);hash.update(await readFile(file));}const sourceHash=hash.digest('hex');
 const encoder=spawn(ff,['-y','-hide_banner','-loglevel','warning','-f','image2pipe','-vcodec','mjpeg','-framerate','30','-i','pipe:0','-i','public/mix.wav','-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart','out/The_Prince_and_the_Ghost_Ship.mp4'],{stdio:['pipe','ignore','pipe']});let log='';encoder.stderr.on('data',d=>{log+=d.toString();});const done=new Promise((resolve,reject)=>{encoder.on('error',reject);encoder.on('close',code=>code===0?resolve():reject(Error('Encoder '+code+' '+log)));});
 const start=Date.now();let count=0;
 for(const shot of shots){const folder=`frames/${shot.id}`;await mkdir(folder,{recursive:true});for(let f=shot.start;f<shot.end;f++){const jpeg=Buffer.from(await page.evaluate(f=>window.captureFrame(f),f),'base64');await writeFile(`${folder}/f${String(f).padStart(4,'0')}.jpg`,jpeg);if(!encoder.stdin.write(jpeg))await once(encoder.stdin,'drain');count++;if(count%60===0)console.log(`${count}/1550 frames; ${Math.round((Date.now()-start)/1000)} s elapsed`);}await writeFile(`${folder}/manifest.json`,JSON.stringify({scene:shot.id,start:shot.start,end:shot.end,count:shot.end-shot.start,sourceHash},null,2));console.log(shot.id+' captured');}
 encoder.stdin.end();await done;if(errors.length)throw Error(errors.join('\n'));await writeFile('out/render.json',JSON.stringify({sourceHash,frames:count,width:1080,height:1920,fps:30,duration:51.6440625,errors,elapsedSeconds:(Date.now()-start)/1000},null,2));await writeFile('out/encode.log',log);console.log('Video complete.');
}finally{await browser.close();}
