import {mkdir,readFile,writeFile,copyFile} from 'node:fs/promises';
const root=new URL('../../../',import.meta.url),project=new URL('../',import.meta.url);
const base={project:'flying-dutchman',coat:false,skin:'#faf9f5',boots:'#262838',pants:'#343e52',light:-2.2};
const characters=[
 {...base,id:'dutchman-george',identity:'dutchman-george',name:'Prince George · naval cadet',seed:18,jacket:'#344e70',hair:'#694533',hairStyle:'sidepart',build:'kid',outfit:{hat:'cap',cap:'#273b59',buttons:'#dabf79'}},
 {...base,id:'dutchman-lookout',identity:'dutchman-lookout',name:'Lookout · Henry',seed:24,jacket:'#bacbd4',hair:'#a27243',hairStyle:'sidepart',outfit:{hat:'cap',cap:'#eee6ce',buttons:'#506579'}},
 {...base,id:'dutchman-officer',identity:'dutchman-officer',name:'Watch officer',seed:31,jacket:'#273b50',hair:'#614638',hairStyle:'receding',outfit:{hat:'cap',cap:'#23384a',moustache:'#684735',buttons:'#d9b875'}},
 {...base,id:'dutchman-midshipman',identity:'dutchman-midshipman',name:'Investigating midshipman',seed:8,jacket:'#557078',hair:'#342f30',hairStyle:'sidepart',outfit:{hat:'cap',cap:'#23384a',buttons:'#d9b875'}}
];
const file=new URL('references/characters/cast.json',root),catalog=JSON.parse(await readFile(file));
for(const c of characters)if(!catalog.characters.some(d=>d.id===c.id))catalog.characters.push(c);
await writeFile(file,JSON.stringify(catalog,null,2)+'\n');
const saved=new URL('references/characters/flying-dutchman/',root);await mkdir(new URL('engine/',saved),{recursive:true});
await writeFile(new URL('cast-design.json',saved),JSON.stringify({characters},null,2));
for(const name of ['character-rig.ts','toon.ts','style.ts','face-style.ts','director.ts','hair-3d.ts','angle-designs.ts'])await copyFile(new URL('templates/bridge/'+name,root),new URL('engine/'+name,saved));
await copyFile(new URL('package-lock.json',root),new URL('package-lock.json',project));
await writeFile(new URL('package.json',project),JSON.stringify({name:'flying-dutchman-short',private:true,type:'module',scripts:{dev:'vite --host 127.0.0.1 --port 8791 --strictPort',build:'vite build',render:'node scripts/capture.mjs'},dependencies:{three:'~0.170.0'},devDependencies:{vite:'^6.4.0',playwright:'^1.56.0'}},null,2));
console.log('Original navy cast preserved.');
