import {chromium} from 'playwright';
import {mkdir,writeFile} from 'node:fs/promises';
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true,args:['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--disable-accelerated-2d-canvas']});
try{const page=await browser.newPage({viewport:{width:1080,height:1920}});const errors=[];page.on('pageerror',e=>{errors.push(e.message);console.error(e.message);});await page.goto('http://127.0.0.1:8791/?scale=1');await page.waitForFunction(()=>window.ready,{},{timeout:120000});await mkdir('review',{recursive:true});
 const shots=await page.evaluate(()=>window.shots);for(const s of shots.filter(s=>!process.argv[2]||s.id===process.argv[2])){const frames=[s.start,Math.floor((s.start+s.end)/2),s.end-1];for(const f of frames){const jpg=await page.evaluate(f=>window.captureFrame(f),f);await writeFile(`review/${s.id}-${f}.jpg`,Buffer.from(jpg,'base64'));}console.log(s.id+' reviewed');}
 for(const f of process.argv[2]==='S04'?[750,780,810,840,870]:[534,630,798,814,1002,1004,1160,1260,1350,1470]){const jpg=await page.evaluate(f=>window.captureFrame(f),f);await writeFile(`review/cue-${f}.jpg`,Buffer.from(jpg,'base64'));}
 if(errors.length)throw Error(errors.join('\n'));await writeFile('work/shots.json',JSON.stringify({shots:shots.map(s=>({id:s.id,a:s.start,b:s.end})),planned:[[1002,1005]]},null,2));console.log('Review captures complete.');
}finally{await browser.close();}
