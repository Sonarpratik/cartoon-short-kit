import {chromium} from 'playwright';import {mkdir,writeFile} from 'node:fs/promises';
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',args:['--disable-accelerated-2d-canvas']});
try{
 const page=await browser.newPage();await page.goto('http://127.0.0.1:8791');await page.waitForFunction(()=>window.ready);
 const result=await page.evaluate(async()=>{
  const {drawCharacter}=await import('/characters/character-rig.ts'),{characterAngleDesigns}=await import('/characters/angle-designs.ts'),{characters}=await fetch('/characters/cast.json').then(r=>r.json());
  const canvas=document.createElement('canvas');canvas.width=1600;canvas.height=1020;const g=canvas.getContext('2d');g.fillStyle='#e8e3d7';g.fillRect(0,0,1600,1020);
  const labels=['GEORGE · CADET','HENRY · LOOKOUT','WATCH OFFICER','MIDSHIPMAN'];
  const sheets=characters.map((d,i)=>{
   g.save();g.translate(i*400+20,160);g.scale(.6,.6);drawCharacter(g,d,{yaw:15,time:0,micro:false});g.restore();g.fillStyle='#302d37';g.font='bold 21px sans-serif';g.textAlign='center';g.fillText(labels[i],i*400+200,55);
   const c=document.createElement('canvas');c.width=1200;c.height=1560;const ctx=c.getContext('2d');ctx.fillStyle='#e8e3d7';ctx.fillRect(0,0,1200,1560);
   for(let j=0;j<12;j++){ctx.save();ctx.translate(j%4*300,Math.floor(j/4)*520);ctx.scale(.48,.48);drawCharacter(ctx,d,{yaw:j*30,time:0,micro:false});ctx.restore();ctx.fillStyle='#302d37';ctx.font='16px sans-serif';ctx.fillText(j*30+' degrees',j%4*300+12,Math.floor(j/4)*520+510);}
   // Check elevation, gait, expressions and attachment transforms in the action sheet.
   const poses=[{yaw:90,action:'walk',time:.24},{yaw:30,expression:'shock',time:2},{yaw:30,pitch:65,time:0},{yaw:180,pitch:-35,time:0}];
   poses.forEach((pose,j)=>{g.save();g.translate(i*400+j*100,810);g.scale(.16,.16);drawCharacter(g,d,{...pose,micro:true});g.restore();});
   return {id:d.id,png:c.toDataURL().split(',')[1],designs:characterAngleDesigns(d.hairStyle,d.outfit.hat)};
  });
  return {png:canvas.toDataURL().split(',')[1],sheets};
 });
 await mkdir('review/cast-v2',{recursive:true});await writeFile('review/cast-v2/lineup.png',Buffer.from(result.png,'base64'));
 for(const s of result.sheets){const folder='../../references/characters/flying-dutchman-v2/turnarounds';await mkdir(folder,{recursive:true});await writeFile(`${folder}/${s.id}.png`,Buffer.from(s.png,'base64'));await writeFile(`${folder}/${s.id}.json`,JSON.stringify({schemaVersion:1,character:s.id,views:s.designs},null,2));}
 console.log('Saved cast lineup, action samples and all four 12-view sheets.');
}finally{await browser.close();}
