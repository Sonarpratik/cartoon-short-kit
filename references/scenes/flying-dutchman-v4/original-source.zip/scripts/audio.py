from pathlib import Path
import subprocess,json
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter,sosfilt
import imageio_ffmpeg
root=Path(__file__).resolve().parents[1];ff=imageio_ffmpeg.get_ffmpeg_exe();sr=48000
subprocess.run([ff,'-y','-v','error','-i',str(root/'public/narration.mp3'),'-ar',str(sr),'-ac','1',str(root/'work/voice-full.wav')],check=True)
_,voice=wavfile.read(root/'work/voice-full.wav');voice=voice.astype(np.float64)/32768;n=len(voice);t=np.arange(n)/sr
gate=np.abs(voice)>.012;rms=np.sqrt(np.mean(voice[gate]**2));rng=np.random.default_rng(1881)
noise=sosfilt(butter(2,[130,1600],fs=sr,btype='bandpass',output='sos'),rng.normal(0,1,n))
waves=noise*(.5+.3*np.sin(t*.65)+.12*np.sin(t*1.23))
env=np.minimum(1,t/1.1)*np.minimum(1,(n/sr-t)/1.2);env*=np.where(t<39.6,1,.2)
ambience=waves/np.sqrt(np.mean(waves**2))*rms*.10*env
# Restrained original timber creaks, with no impact/fall effect.
creak=np.zeros(n)
for cue in [3.9,10.4,24.0,26.0,34.3]:
 a=int(cue*sr);length=min(int(.7*sr),n-a);u=np.arange(length)/sr
 sound=np.sin(2*np.pi*(185*u+7*np.sin(u*7)))*np.sin(np.pi*u/.7)**2*np.exp(-u*3)
 creak[a:a+length]+=sound*rms*.15
mix=voice+ambience+creak;gain=min(1,.94/max(np.max(np.abs(mix)),1e-8));mix*=gain
wavfile.write(root/'public/mix.wav',sr,(mix*32767).astype(np.int16))
(root/'work/audio-report.json').write_text(json.dumps({'duration':n/sr,'voice_gated_rms':float(rms),'ambience_target_relative_rms':.1,'common_gain':gain,'peak':float(np.max(np.abs(mix))),'speech_timing':'Original samples, no retiming or inserted silence','music':'None; original ocean ambience and restrained timber creaks only'},indent=2))
print('Audio prepared',n/sr,'seconds; peak',np.max(np.abs(mix)))
