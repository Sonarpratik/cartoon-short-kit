import * as T from 'three';
import {drawCharacter,relativeView} from '../characters/character-rig';
import cast from '../characters/cast.json';
import {box,cylinder,line,sphere,mat,woodTexture,lantern,book} from './props';
import {sailingShip as ship,animateShip} from './sailing-ship';
import {seaMaterial,SeaLife} from './sea-life';

class Actor {
 canvas=document.createElement('canvas');ctx:CanvasRenderingContext2D;texture:T.CanvasTexture;mesh:T.Mesh;shadow:T.Mesh;heading=0;action='idle';expression='neutral';gaitPhase:number|undefined;locomotionBlend:number|undefined;
 constructor(public design:any,root:T.Object3D,x:number,z:number,public height=2.5){this.canvas.width=480;this.canvas.height=800;this.ctx=this.canvas.getContext('2d')!;this.texture=new T.CanvasTexture(this.canvas);this.texture.colorSpace=T.SRGBColorSpace;this.texture.minFilter=T.LinearFilter;this.mesh=new T.Mesh(new T.PlaneGeometry(height*.6,height),new T.MeshBasicMaterial({map:this.texture,transparent:true,depthWrite:false,side:T.DoubleSide}));this.mesh.position.set(x,2.33+height*.475,z);root.add(this.mesh);
 const c=document.createElement('canvas');c.width=c.height=64;const p=c.getContext('2d')!,grad=p.createRadialGradient(32,32,1,32,32,32);grad.addColorStop(0,'rgba(15,20,35,.55)');grad.addColorStop(1,'rgba(15,20,35,0)');p.fillStyle=grad;p.fillRect(0,0,64,64);this.shadow=new T.Mesh(new T.PlaneGeometry(.9,.65),new T.MeshBasicMaterial({map:new T.CanvasTexture(c),transparent:true,depthWrite:false}));this.shadow.rotation.x=-Math.PI/2;this.shadow.position.set(x,2.335,z);root.add(this.shadow);}
 projectLeg(p:[number,number,number],camera:T.PerspectiveCamera):[number,number]{
  const a=this.mesh.position,c=camera.position,s=this.height/1000,h=this.heading*Math.PI/180,b=Math.atan2(c.x-a.x,c.z-a.z),nx=Math.sin(b),nz=Math.cos(b);
  const wx=a.x+(p[0]*Math.cos(h)+p[2]*Math.sin(h))*s,wy=2.33+(975-p[1])*s,wz=a.z+(-p[0]*Math.sin(h)+p[2]*Math.cos(h))*s;
  const along=((a.x-c.x)*nx+(a.z-c.z)*nz)/((wx-c.x)*nx+(wz-c.z)*nz),hx=c.x+(wx-c.x)*along,hz=c.z+(wz-c.z)*along,hy=c.y+(wy-c.y)*along;
  return [300+((hx-a.x)*Math.cos(b)-(hz-a.z)*Math.sin(b))/s,500-(hy-a.y)/s];
 }
 update(t:number,camera:T.PerspectiveCamera){const a=this.mesh.position,c=camera.position;
 // Upright cards keep the soles on the deck. Perspective supplies elevation
 // foreshortening once; pitching both the card and drawing distorted the body.
 this.mesh.rotation.set(0,Math.atan2(c.x-a.x,c.z-a.z),0);
 this.ctx.clearRect(0,0,480,800);this.ctx.save();this.ctx.scale(.8,.8);drawCharacter(this.ctx,this.design,{yaw:relativeView(this.heading,c.x,c.z,a.x,a.z),pitch:0,time:t,action:this.action,gaitPhase:this.gaitPhase,locomotionBlend:this.locomotionBlend,projectLeg:p=>this.projectLeg(p,camera),expression:this.expression,expressionAge:Math.max(0,t-(this.expression==='shock'?26:17)),fromExpression:'neutral',light:-2.2});this.ctx.restore();this.texture.needsUpdate=true;this.shadow.position.x=a.x;this.shadow.position.z=a.z;}
}
export class World {
 scene=new T.Scene();deck=new T.Group();seaRoot=new T.Group();cabin=new T.Group();ghost=ship(true);vessel:T.Group;life:SeaLife;ghostOpacity=0;actors:Actor[]=[];moon:T.DirectionalLight;ambient:T.HemisphereLight;water:T.Mesh;ghostLight:T.PointLight;stars:T.Points;morning=false;lampLights:T.PointLight[]=[];moonDisc:T.Mesh;cap:T.Group;books:T.Group[]=[];
 constructor(){
 this.scene.background=new T.Color('#101f37');this.scene.fog=new T.FogExp2('#182c43',.008);this.scene.add(this.deck,this.seaRoot,this.cabin);
 this.ambient=new T.HemisphereLight('#7eabc6','#242234',1.3);this.scene.add(this.ambient);this.moon=new T.DirectionalLight('#a6cbe9',2);this.moon.position.set(-15,24,9);this.moon.castShadow=true;this.moon.shadow.mapSize.set(1024,1024);this.moon.shadow.camera.left=-15;this.moon.shadow.camera.right=15;this.moon.shadow.camera.top=15;this.moon.shadow.camera.bottom=-15;this.moon.shadow.bias=-.001;this.moon.shadow.normalBias=.04;this.scene.add(this.moon);
 this.vessel=ship();this.deck.add(this.vessel);this.lampLights.push(lantern(this.deck,-2.1,3.3,-3.1),lantern(this.deck,2.3,3.2,4));this.life=new SeaLife(this.seaRoot,this.deck);
 // Compass binnacle with a glazed face, brass hood and supporting cabinet.
 const brass=mat('#b79d67',{metalness:.5});cylinder(this.deck,.32,.24,1.15,-1.4,2.9,-4,mat('#685445'));sphere(this.deck,.35,-1.4,3.55,-4,brass);const glass=cylinder(this.deck,.24,.24,.025,-1.4,3.85,-4,mat('#d8e0bf'));line(this.deck,[[-1.5,3.87,-4],[-1.3,3.87,-4]],'#bd6556');
 const waterGeo=new T.PlaneGeometry(500,500,100,100);waterGeo.rotateX(-Math.PI/2);this.water=new T.Mesh(waterGeo,seaMaterial());this.water.position.y=-.06;this.seaRoot.add(this.water);
 // Broad sparse silver-blue wavelets, each moves with the same calm swell.
 for(let i=0;i<200;i++){const x=Math.sin(i*89.3)*90,z=Math.cos(i*32.13)*90;line(this.seaRoot,[[x,.025,z],[x+1.5+(i%5)*.5,.035,z+.08]],i%4===0?'#537686':'#315a6b',.5);}
 this.moonDisc=sphere(this.seaRoot,2.8,-45,49,-100,new T.MeshBasicMaterial({color:'#d7decd'}));
 const pos=[];for(let i=0;i<450;i++){const a=i*2.39996,yy=10+(i%53)*1.4;pos.push(Math.sin(a)*140,yy,Math.cos(a)*140);}this.stars=new T.Points(new T.BufferGeometry().setAttribute('position',new T.Float32BufferAttribute(pos,3)),new T.PointsMaterial({color:'#c4d9df',size:.17,transparent:true,opacity:.7}));this.seaRoot.add(this.stars);
 this.ghost.scale.setScalar(.82);this.ghost.rotation.y=-.95;this.ghost.position.set(-22,.05,-32);this.scene.add(this.ghost);this.ghostLight=new T.PointLight('#ed4957',125,48,2);this.ghostLight.position.set(-20,4,-27);this.scene.add(this.ghostLight);
 for(const [i,x,z,h] of [[0,.5,-1.8,2.4],[1,-2.15,1.6,2.6],[2,1.6,-5.6,2.75],[3,.6,-.2,2.5]])this.actors.push(new Actor(cast.characters[i],this.deck,x,z,h));
 this.actors[0].heading=-35;this.actors[1].heading=-70;this.actors[2].heading=-30;this.actors[3].heading=-60;
 this.cap=new T.Group();this.cap.position.set(-.9,2.39,2);this.deck.add(this.cap);const top=sphere(this.cap,.23,0,.10,0,mat('#dbd8bf'));top.scale.set(1,.35,1);cylinder(this.cap,.2,.19,.1,0,.04,0,mat('#34485a'));box(this.cap,.23,.025,.18,0,.03,.17,mat('#34485a'));this.cap.visible=false;
 this.buildCabin();
 }
 buildCabin(){const g=this.cabin,wall=mat('#486361'),trim=mat('#b3a077'),wood=mat('#8f654a',{map:woodTexture()}),dark=mat('#304946');
 box(g,8,.2,7,0,-.12,0,wood);box(g,8,.18,7,0,4.6,0,mat('#536c66'));box(g,8,4.6,.2,0,2.2,-3.5,wall);box(g,.2,4.6,7,-4,2.2,0,wall);box(g,8,4.6,.2,0,2.2,3.5,wall);
 // Starboard wall built around two true openings instead of a missing wall.
 box(g,.2,1.5,7,4,.7,0,wall);box(g,.2,1,7,4,4.1,0,wall);for(const z of [-2.8,0,2.8])box(g,.2,2.45,1.4,4,2.7,z,wall);
 for(const z of [-1.4,1.4]){for(const y of [1.5,3.6])box(g,.35,.1,1.6,3.95,y,z,trim);for(const dz of [-.8,0,.8])box(g,.28,2.2,.06,3.95,2.55,z+dz,trim);box(g,.28,.055,1.6,3.95,2.55,z,trim);}
 for(const z of [-3.35,3.35]){box(g,7.8,.13,.1,0,1.1,z,trim);box(g,7.8,.16,.1,0,.15,z,trim);}for(let x=-3.6;x<4;x+=1.2)box(g,.06,1,.06,x,.6,-3.35,trim);
 box(g,6.5,.19,3,0,1.53,-.4,wood);box(g,6.3,.3,.12,0,1.3,.98,wood);for(const x of [-2.85,2.85])for(const z of [-1.6,.75])box(g,.18,1.45,.18,x,.65,z,wood);for(const x of [-2.85,2.85])box(g,.12,.12,2.4,x,.35,-.4,wood);
 this.books=[book(g,-1.45,-.45,'log'),book(g,1.45,-.45,'account')];this.books[0].rotation.y=.08;this.books[1].rotation.y=-.07;
 lantern(g,-2.75,2.25,-1.4);cylinder(g,.16,.17,.26,2.7,1.77,.5,mat('#263a48'));line(g,[[2.7,1.82,.5],[2.9,2.25,.3]],'#453932');
 box(g,2.1,2.5,.6,-2.5,1.25,-3.07,dark);for(let y=.3;y<2.5;y+=.44){box(g,1.98,.38,.08,-2.5,y,-2.71,wood);box(g,.2,.045,.05,-2.5,y,-2.64,trim);}
 cylinder(g,.12,.12,1.2,2.6,.6,-2.7,wood);sphere(g,.55,2.6,1.68,-2.7,mat('#92aa9b'));const globe=new T.Mesh(new T.TorusGeometry(.64,.03,8,40),trim);globe.position.set(2.6,1.68,-2.7);globe.rotation.z=.3;g.add(globe);
 const sky=new T.Mesh(new T.PlaneGeometry(8,5),new T.MeshBasicMaterial({color:'#d6dec6'}));sky.rotation.y=-Math.PI/2;sky.position.set(6,2.5,0);g.add(sky);
 const sun=new T.SpotLight('#ffdfaa',100,22,Math.PI/5,.1,1.3);sun.position.set(7,5,3);sun.target.position.set(-2,.1,-2);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);sun.shadow.bias=-.001;g.add(sun,sun.target);
 }
 setGhost(opacity:number){this.ghostOpacity=opacity;this.ghost.visible=opacity>.001;this.ghostLight.intensity=125*opacity;this.ghost.traverse((o:any)=>{if(o.isMesh||o.isLine)o.material.opacity=(o.material.userData.baseOpacity??.9)*opacity;});}
 update(t:number,camera:T.PerspectiveCamera,mode:string){const cabin=mode==='cabin';this.cabin.visible=cabin;this.deck.visible=!cabin;this.seaRoot.visible=!cabin;this.ghost.visible=!cabin&&this.ghost.visible;this.ghostLight.visible=!cabin;
 const morning=mode==='morning';this.morning=morning;this.scene.background=new T.Color(cabin?'#4d655f':morning?'#c1d6d0':'#12253d');(this.scene.fog as T.FogExp2).color.copy(this.scene.background);this.moon.color.set(morning?'#ffe2ab':'#a9d1f0');this.moon.intensity=cabin?.35:morning?2.7:2;this.ambient.intensity=cabin?.8:morning?1.45:1.25;this.stars.visible=!morning;this.moonDisc.visible=!morning;
 this.cap.visible=morning;this.actors[1].mesh.visible=!morning&&t<23.5;this.actors[1].shadow.visible=!morning&&t<23.5;
 const waterMat=this.water.material as T.ShaderMaterial;waterMat.uniforms.time.value=t;waterMat.uniforms.day.value=morning?1:0;waterMat.uniforms.ghost.value=this.ghostOpacity;
 this.ghost.position.set(-22+.65*Math.sin(t*.15),.12+Math.sin(t*.7)*.11,-32+.5*Math.cos(t*.2));this.ghost.rotation.z=.012*Math.sin(t*.5);waterMat.uniforms.ghostXZ.value.set(this.ghost.position.x,this.ghost.position.z);animateShip(this.vessel,t);animateShip(this.ghost,t);this.life.update(t,this.ghostOpacity,morning);
 for(let i=0;i<this.lampLights.length;i++)this.lampLights[i].intensity=(morning?5:15)*(1+.055*Math.sin(t*3.4+i*2)+.025*Math.sin(t*8.1));
 const look=Math.max(0,Math.min(1,(t-16.2)/1.2)),turn=look*look*(3-2*look);this.actors[1].action=t>16.4&&t<19.6?'reach':'idle';this.actors[1].heading=-70-60*turn;this.actors[1].expression=t>17?'nervous':'neutral';this.actors[2].heading=-30-108*turn;
 if(!cabin)for(const actor of this.actors)actor.update(t,camera);
 }
}
