import type {CameraPose} from '../characters/director';
export type V3=[number,number,number];
export const ease=(u:number)=>{const t=Math.max(0,Math.min(1,u));return t*t*(3-2*t);};
export const blend=(a:V3,b:V3,t:number):V3=>a.map((x,i)=>x+(b[i]-x)*t) as V3;
/** Bezier travel stays inside its control hull: no spline target overshoot. */
export function curve(u:number,points:V3[]):V3{let p=points.map(v=>[...v] as V3);for(let n=p.length-1;n>0;n--)for(let i=0;i<n;i++)p[i]=blend(p[i],p[i+1],u);return p[0];}
export function shotCurve(u:number,positions:V3[],targets:V3[],fov=44,endFov=fov):CameraPose{const t=ease(u);return {position:curve(t,positions),target:curve(t,targets),fov:fov+(endFov-fov)*t};}
