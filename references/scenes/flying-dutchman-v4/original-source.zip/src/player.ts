import * as T from 'three';
import {World} from './world';
import {cameraJourney} from '../characters/director';
import {SHOTS,FPS,TOTAL} from './scenes';
import {investigationCamera} from './scenes/S04';
import {midshipmanMotion} from './locomotion';
import {recallCamera} from './scenes/S03';
const api=window as any;api.ready=false;
const scale=Number(new URLSearchParams(location.search).get('scale')||.5),renderer=new T.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});
renderer.setSize(Math.round(1080*scale),Math.round(1920*scale));renderer.setPixelRatio(1);renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.18;
document.querySelector('#screen')!.append(renderer.domElement);
const world=new World(),camera=new T.PerspectiveCamera(43,9/16,.1,400),slider=document.querySelector('#frame') as HTMLInputElement,voice=document.querySelector('#voice') as HTMLAudioElement,button=document.querySelector('#play') as HTMLButtonElement;
api.debugWorld=world;
api.debugCamera=camera;
slider.max=String(TOTAL-1);let frame=0,playing=false,lastMode='';renderer.shadowMap.autoUpdate=false;
const smooth=(a:number,b:number,x:number)=>{const u=Math.min(1,Math.max(0,(x-a)/(b-a)));return u*u*(3-2*u);};
api.renderFrame=(f:number)=>{if(f<0||f>=TOTAL)throw Error('Frame out of range');frame=f;const t=f/FPS,s=SHOTS.find(s=>f>=s.start&&f<s.end)!,u=(f-s.start)/(s.end-s.start-1);let pose=s.id==='S04'?investigationCamera(u,t):'camera'in s?s.camera(u,t):cameraJourney(u,s.keys as any);
 let mode:string=s.mode;
 // The account names the apparition before the deliberate cut to later morning.
 if(s.id==='S05'&&t<33.44){mode='night';pose=recallCamera((t-30.9)/(33.44-30.9));}
 camera.position.set(...pose.position);camera.lookAt(...pose.target);camera.fov=pose.fov??43;camera.updateProjectionMatrix();
 const reveal=smooth(16.8,18.9,t),vanish=1-smooth(26.5,27.15,t),recall=t>=30.9&&t<33.44?1:0;world.setGhost(Math.max(reveal*vanish,recall));
 world.actors[0].expression=t>17&&t<33.44?'nervous':t>=33.44?'pained':'neutral';world.actors[0].heading=-145*smooth(16.8,18.1,t);world.actors[2].expression=t>=33.44?'pained':t>18?'nervous':'stern';
 const mid=world.actors[3],walk=midshipmanMotion(t,mid.height);mid.mesh.position.x=t<23.5?-1.6:2.1;mid.mesh.position.z=t<23.5?3:walk.z;mid.action=walk.walking?'walk':'idle';mid.gaitPhase=walk.phase;mid.locomotionBlend=walk.blend;mid.heading=180;mid.expression=t>26?'shock':'nervous';
 world.update(t,camera,mode);if(lastMode!==mode||f%6===0){renderer.shadowMap.needsUpdate=true;lastMode=mode;}renderer.render(world.scene,camera);slider.value=String(f);document.querySelector('#time')!.textContent=`${s.id} · ${t.toFixed(2)} s`;api.cameraPose={position:camera.position.toArray(),target:pose.target};};
api.captureFrame=(f:number)=>{api.renderFrame(f);return renderer.domElement.toDataURL('image/jpeg',.93).split(',')[1];};
button.onclick=async()=>{playing=!playing;button.textContent=playing?'Pause':'Play';if(playing){if(frame>=TOTAL-1)frame=0;voice.currentTime=frame/FPS;await voice.play();}else voice.pause();};
slider.oninput=()=>{playing=false;voice.pause();button.textContent='Play';api.renderFrame(Number(slider.value));voice.currentTime=frame/FPS;};
function tick(){if(playing){api.renderFrame(Math.min(TOTAL-1,Math.floor(voice.currentTime*FPS)));if(voice.ended){playing=false;button.textContent='Play';}}requestAnimationFrame(tick);}
api.shots=SHOTS.map(({id,start,end})=>({id,start,end}));api.totalFrames=TOTAL;api.fps=FPS;api.renderFrame(0);api.ready=true;requestAnimationFrame(tick);
