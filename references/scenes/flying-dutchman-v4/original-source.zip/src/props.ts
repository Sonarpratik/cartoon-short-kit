import * as T from 'three';
export const mat=(color:string,extra:any={})=>new T.MeshStandardMaterial({color,roughness:.82,...extra});
export function box(g:T.Object3D,w:number,h:number,d:number,x:number,y:number,z:number,m:T.Material){const o=new T.Mesh(new T.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;g.add(o);return o;}
export function cylinder(g:T.Object3D,r:number,rt:number,h:number,x:number,y:number,z:number,m:T.Material){const o=new T.Mesh(new T.CylinderGeometry(rt,r,h,16),m);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;g.add(o);return o;}
export function line(g:T.Object3D,points:number[][],color='#403a3d',opacity=1){const o=new T.Line(new T.BufferGeometry().setFromPoints(points.map(p=>new T.Vector3(...p as [number,number,number]))),new T.LineBasicMaterial({color,transparent:opacity<1,opacity}));g.add(o);return o;}
export function sphere(g:T.Object3D,r:number,x:number,y:number,z:number,m:T.Material){const o=new T.Mesh(new T.SphereGeometry(r,20,14),m);o.position.set(x,y,z);g.add(o);return o;}
export function woodTexture(){const c=document.createElement('canvas');c.width=512;c.height=512;const p=c.getContext('2d')!;p.fillStyle='#8d6349';p.fillRect(0,0,512,512);for(let j=0;j<8;j++){p.fillStyle=j%2?'#9e7353':'#93664b';p.fillRect(0,j*64,512,62);p.fillStyle='#493c36';p.fillRect(0,j*64,512,2);for(let i=0;i<7;i++){p.strokeStyle='rgba(47,32,36,.16)';p.beginPath();p.moveTo(i*83-20,j*64+15+i*5);p.bezierCurveTo(i*83+35,j*64+12,i*83+53,j*64+22,i*83+100,j*64+18+i*5);p.stroke();}for(const x of [10,250,500]){p.fillStyle='#574638';p.beginPath();p.arc(x,j*64+9,1.7,0,7);p.fill();}}const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(2,4);return t;}
export function ship(ghost=false){
 const g=new T.Group(),wood=mat(ghost?'#9f3342':'#544344'),edge=mat(ghost?'#ee6c67':'#b79865'),deck=mat(ghost?'#7f3945':'#a67d57',ghost?{}:{map:woodTexture()}),dark=mat('#273541'),sail=mat(ghost?'#e7988e':'#b9c9ca',{side:T.DoubleSide,...(ghost?{emissive:'#b93043',emissiveIntensity:.9,transparent:true,opacity:.7}:{})});
 const hull=new T.Shape();hull.moveTo(-3.4,-8);hull.lineTo(-3.4,6.5);hull.quadraticCurveTo(-2.7,10,0,11);hull.quadraticCurveTo(2.7,10,3.4,6.5);hull.lineTo(3.4,-8);hull.quadraticCurveTo(0,-9.3,-3.4,-8);
 const geo=new T.ExtrudeGeometry(hull,{depth:2,bevelEnabled:true,bevelSize:.3,bevelThickness:.2,bevelSegments:2,steps:1});geo.rotateX(-Math.PI/2);const h=new T.Mesh(geo,wood);h.position.y=.1;h.castShadow=h.receiveShadow=true;g.add(h);
 const deckGeo=new T.ShapeGeometry(hull);deckGeo.rotateX(-Math.PI/2);const surface=new T.Mesh(deckGeo,deck);surface.position.y=2.31;surface.receiveShadow=true;g.add(surface);
 for(const side of [-1,1]){box(g,.18,.7,15.2,side*3.33,2.66,-.15,wood);box(g,.26,.12,15.3,side*3.33,3.05,-.15,edge);for(let z=-7;z<7;z+=1.8){box(g,.23,.88,.22,side*3.27,2.74,z,edge);line(g,[[side*3.25,3.4,z],[side*3.25,3.4,z+1.8]],'#6c726d');}line(g,[[side*3.3,3.05,-7.8],[side*2.8,3.05,-9],[0,3.05,-10.7]],'#ba9c76');}
 box(g,2.7,.9,2,0,2.8,3.7,dark);box(g,2.9,.14,2.2,0,3.28,3.7,edge);for(let z=3;z<=4.4;z+=.3)box(g,2.5,.06,.045,0,3.37,z,wood);
 for(const z of [-3.5,4.5]){
  cylinder(g,.13,.08,12,0,8.25,z,wood);cylinder(g,.25,.25,.22,0,8.4,z,edge);
  for(const [y,width] of [[7.2,6],[10.1,5],[12.5,3.5]]){const yard=cylinder(g,.065,.065,width,0,y,z,wood);yard.rotation.z=Math.PI/2;
   const shape=new T.Shape();shape.moveTo(-width/2,y-.12);shape.lineTo(width/2,y-.12);shape.quadraticCurveTo(width*.45,y-1.55,width*.32,y-2);shape.quadraticCurveTo(0,y-2.35,-width*.32,y-2);shape.quadraticCurveTo(-width*.45,y-1.55,-width/2,y-.12);
   const cloth=new T.Mesh(new T.ShapeGeometry(shape,10),sail);cloth.position.z=z+.14;cloth.castShadow=!ghost;g.add(cloth);
   for(let j=-1;j<=1;j++)line(g,[[j*width/4,y-.15,z+.15],[j*width/5,y-2.08,z+.15]],ghost?'#f0b2a1':'#859fa4',.35);
  }
  for(const side of [-1,1]){for(let a=0;a<4;a++)line(g,[[side*(2.4+a*.16),2.8,z-1+a*.6],[0,11,z]],ghost?'#f29c91':'#68727a',.7);for(let y=3.5;y<10;y+=.45){const x=3*(11-y)/8.2;line(g,[[side*x,y,z-.8],[side*x,y,z+.8]],ghost?'#bf6268':'#758087',.6);}}
 }
 const wheel=new T.Group();wheel.position.set(0,3.3,-5.8);g.add(wheel);const ring=new T.Mesh(new T.TorusGeometry(.65,.06,8,32),edge);wheel.add(ring);for(let j=0;j<8;j++){const a=j*Math.PI/4;line(wheel,[[Math.sin(a)*.86,Math.cos(a)*.86,0],[0,0,0]],'#c4a879');}cylinder(g,.12,.12,1.2,0,2.9,-5.8,edge);
 for(const x of [-2.3,2.3]){for(let z=-5;z<7;z+=5){const rope=new T.Mesh(new T.TorusGeometry(.35,.035,6,32),edge);rope.rotation.x=-Math.PI/2;rope.position.set(x,2.37,z);g.add(rope);}}
 if(ghost){g.traverse((o:any)=>{if(o.isMesh){o.material=o.material.clone();o.material.transparent=true;o.material.opacity=o.material.opacity??.8;o.material.emissive=new T.Color('#7c172b');o.material.emissiveIntensity=.7;o.castShadow=false;}});}
 return g;
}
export function lantern(g:T.Object3D,x:number,y:number,z:number){const brass=mat('#b19a5f',{metalness:.5,roughness:.4});cylinder(g,.16,.14,.08,x,y-.26,z,brass);cylinder(g,.18,.08,.18,x,y+.24,z,brass);cylinder(g,.12,.12,.45,x,y,z,mat('#ffd386',{emissive:'#ffb75a',emissiveIntensity:1.6}));for(const dx of [-.12,.12])for(const dz of [-.08,.08])box(g,.025,.48,.025,x+dx,y,z+dz,brass);const light=new T.PointLight('#ffca87',15,9,2);light.position.set(x,y+.06,z);light.castShadow=true;light.shadow.mapSize.set(512,512);light.shadow.bias=-.003;g.add(light);return light;}
export function book(g:T.Object3D,x:number,z:number,kind:'log'|'account'){
 const group=new T.Group();group.position.set(x,1.65,z);g.add(group);const leather=mat(kind==='log'?'#284d57':'#874d45'),paper=mat('#e9d9ac');box(group,2.8,.12,2.05,0,0,0,leather);box(group,2.65,.12,1.91,0,.12,0,paper);
 const c=document.createElement('canvas');c.width=1200;c.height=900;const p=c.getContext('2d')!;p.fillStyle='#f1e4c2';p.fillRect(0,0,1200,900);p.strokeStyle='#b9a782';p.lineWidth=4;p.strokeRect(20,20,1160,860);p.fillStyle='#453d35';p.textAlign='center';p.font='bold 54px Georgia';p.fillText(kind==='log'?'NAVAL LOG':'THE CRUISE OF',600,130);p.font='bold 40px Georgia';p.fillText(kind==='log'?'11 JULY 1881':'H.M.S. BACCHANTE',600,200);p.font='30px Georgia';p.fillText(kind==='log'?'H.M.S. INCONSTANT':'Published voyage account · 1886',600,265);p.textAlign='left';p.font='32px Georgia';
 const lines=kind==='log'?['10.45 a.m.','Henry Youle, ordinary seaman,','killed by a fall from aloft.','','Buried at sea.']:['July 11th, 1881.','At 4 a.m. a strange red light','was reported off the port bow.','','Thirteen persons saw her.'];
 lines.forEach((s,i)=>p.fillText(s,100,390+i*68));p.font='italic 24px Georgia';p.fillStyle='#76634e';p.fillText('Illustrative reconstruction',100,820);
 const texture=new T.CanvasTexture(c);texture.colorSpace=T.SRGBColorSpace;const page=new T.Mesh(new T.PlaneGeometry(2.62,1.9),new T.MeshStandardMaterial({map:texture,roughness:.95}));page.rotation.x=-Math.PI/2;page.position.y=.187;page.receiveShadow=true;group.add(page);box(group,.035,.015,1.9,0,.2,0,mat('#a48c69'));return group;
}
