import * as T from 'three';
import {box,cylinder,line,mat,woodTexture} from './props';
const V=(x:number,y:number,z:number)=>new T.Vector3(x,y,z);
function spar(g:T.Object3D,a:T.Vector3,b:T.Vector3,r:number,m:T.Material){const v=b.clone().sub(a),o=new T.Mesh(new T.CylinderGeometry(r*.72,r,v.length(),12),m);o.position.copy(a).add(b).multiplyScalar(.5);o.quaternion.setFromUnitVectors(V(0,1,0),v.normalize());o.castShadow=true;g.add(o);return o;}
function curve(g:T.Object3D,points:T.Vector3[],color:string,opacity=.7){const path=new T.CatmullRomCurve3(points),o=new T.Line(new T.BufferGeometry().setFromPoints(path.getPoints(55)),new T.LineBasicMaterial({color,transparent:true,opacity}));g.add(o);return o;}
export function sailingShip(ghost=false){
 const g=new T.Group(),timber=mat(ghost?'#241b27':'#684632',{map:woodTexture(),...(ghost?{emissive:'#3b0d1c',emissiveIntensity:.28}:{})}),trim=mat(ghost?'#6e2937':'#bd9660'),iron=mat('#25333c',{metalness:.5}),planks=mat(ghost?'#32212b':'#aa8056',{map:woodTexture()}),cloth=mat(ghost?'#572332':'#c9d1c8',{side:T.DoubleSide,roughness:1,...(ghost?{emissive:'#b12b40',emissiveIntensity:.25}:{})});
 const sections=[[-11.4,.06],[-10,1.25],[-8,2.6],[-5,3.25],[-1,3.45],[3.5,3.45],[6.5,3.15],[9,2.75]],verts:number[]=[],uv:number[]=[],idx:number[]=[];
 // Actual rounded bilges and a narrow keel; deck height stays fixed for actors.
 sections.forEach(([z,w],row)=>{for(let j=0;j<=18;j++){const a=-Math.PI/2+j/18*Math.PI;verts.push(Math.sin(a)*w,2.3-3*Math.pow(Math.max(0,Math.cos(a)),.75),z);uv.push((z+11.4)/20.4,j/18);if(row<sections.length-1&&j<18){const a=row*19+j,b=a+19;idx.push(a,b,a+1,b,b+1,a+1);}}});
 const hullGeo=new T.BufferGeometry();hullGeo.setAttribute('position',new T.Float32BufferAttribute(verts,3));hullGeo.setAttribute('uv',new T.Float32BufferAttribute(uv,2));hullGeo.setIndex(idx);hullGeo.computeVertexNormals();const hull=new T.Mesh(hullGeo,timber);hull.material.side=T.DoubleSide;hull.castShadow=hull.receiveShadow=true;g.add(hull);
 const shape=new T.Shape();shape.moveTo(0,-11.4);shape.bezierCurveTo(-2.5,-10,-3.45,-6,-3.45,-1);shape.lineTo(-3.45,3.5);shape.quadraticCurveTo(-3.2,7,-2.75,9);shape.lineTo(2.75,9);shape.quadraticCurveTo(3.2,7,3.45,3.5);shape.lineTo(3.45,-1);shape.bezierCurveTo(3.45,-6,2.5,-10,0,-11.4);
 const deckGeo=new T.ShapeGeometry(shape);deckGeo.rotateX(Math.PI/2);const deck=new T.Mesh(deckGeo,planks);deck.position.y=2.31;deck.material.side=T.DoubleSide;deck.receiveShadow=true;g.add(deck);
 for(const side of [-1,1]){
  for(const a of [.43,.72,1.03,1.35])curve(g,sections.map(([z,w])=>V(side*Math.sin(a)*w,2.3-3*Math.pow(Math.cos(a),.75),z)),ghost?'#9c4652':'#b08759',ghost?.65:.7);
  const rail=sections.slice(1).map(([z,w])=>V(side*w,3.02,z));curve(g,rail,ghost?'#c84c5b':'#cfad75',.95);
  for(let z=-7.5;z<8.7;z+=1.55){const width=z<-5?3.05:z>6?2.92:3.38;box(g,.14,.66,1.5,side*width,2.66,z,timber);box(g,.18,.86,.15,side*width,2.72,z+.65,trim);}
  for(const z of [-6,-2,2,6]){box(g,.055,.45,.6,side*(z>5?3.05:3.35),1.58,z,iron);box(g,.09,.055,.7,side*(z>5?3.08:3.39),1.87,z,trim);}
 }
 // Stern gallery, framed windows and carved transom trim.
 box(g,5.4,1.15,.18,0,1.85,9,timber);box(g,5.7,.13,.3,0,2.6,9,trim);box(g,5.7,.12,.3,0,1.12,9,trim);
 for(let x=-1.9;x<=1.91;x+=.95){box(g,.63,.53,.04,x,2.07,9.11,mat(ghost?'#852c3d':'#b4a679',{emissive:ghost?'#ed3b52':'#ffb85e',emissiveIntensity:ghost?1.2:.5}));for(const dx of [-.35,0,.35])box(g,.045,.65,.07,x+dx,2.07,9.15,trim);box(g,.75,.045,.07,x,2.08,9.15,trim);}
 const sails:T.Mesh[]=[],flags:T.Mesh[]=[];
 for(const [mastZ,top,scale] of [[-3.5,15,1],[4.5,14.4,.94],[7.6,10.4,.62]]){
  cylinder(g,.19*scale,.08*scale,top-2.3,0,(top+2.3)/2,mastZ,timber);cylinder(g,.42*scale,.42*scale,.12,0,top*.65,mastZ,trim);
  for(const [yy,ww,hh] of [[top-.8,4*scale,1.75*scale],[top-3.4*scale,5.8*scale,2.35*scale],[top-6.6*scale,7*scale,2.65*scale]]){
   if(yy-hh<3.6)continue;spar(g,V(-ww/2-.22,yy,mastZ),V(ww/2+.22,yy,mastZ),.07*scale,timber);
   const geo=new T.PlaneGeometry(ww,hh,16,10),p=geo.attributes.position;
   for(let i=0;i<p.count;i++){const u=p.getX(i)/ww+.5,v=p.getY(i)/hh+.5,fray=ghost&&v<.13?(.1+.15*Math.sin(i*4.1)**2)*hh:0;p.setXYZ(i,(u-.5)*ww*(.78+.22*v),yy-hh*(1-v)+fray,mastZ+.15-Math.sin(Math.PI*u)*Math.sin(Math.PI*v)*.6*scale);}
   if(ghost){const faces:number[]=[];for(let row=0;row<10;row++)for(let col=0;col<16;col++){const u=(col+.5)/16,v=(row+.5)/10;if(((u-.62)/.10)**2+((v-.43)/.13)**2<1||((u-.22)/.065)**2+((v-.7)/.12)**2<1)continue;const a=row*17+col,b=a+17;faces.push(a,b,a+1,b,b+1,a+1);}geo.setIndex(faces);}
   geo.computeVertexNormals();const sail=new T.Mesh(geo,cloth);sail.castShadow=!ghost;sail.userData.spectralOpacity=.78;sail.userData.base=new Float32Array(p.array);sail.userData.height=hh;sail.userData.top=yy;sail.userData.phase=mastZ+yy;sails.push(sail);g.add(sail);
   for(const u of [.2,.4,.6,.8])curve(g,[V((u-.5)*ww,yy-.02,mastZ+.17),V((u-.5)*ww*.88,yy-hh*.5,mastZ-.4),V((u-.5)*ww*.78,yy-hh+.03,mastZ+.17)],ghost?'#c15665':'#919f9b',.38);
  }
  for(const side of [-1,1]){for(let j=0;j<5;j++)line(g,[[side*3.0,2.8,mastZ-1+j*.48],[0,top*.79,mastZ]],ghost?'#9a4858':'#4c5962',.8);for(let yy=3.2;yy<top*.74;yy+=.48){const width=3*(top*.79-yy)/(top*.79-2.8);line(g,[[side*width,yy,mastZ-.95],[side*width,yy,mastZ+.9]],ghost?'#8f4052':'#63737b',.65);}}
  const flagGeo=new T.PlaneGeometry(1.8*scale,.48*scale,12,3);flagGeo.translate(.9*scale,top+.12,mastZ);const flag=new T.Mesh(flagGeo,mat(ghost?'#3c1826':'#9b4c45',{side:T.DoubleSide}));flag.userData.base=new Float32Array(flagGeo.attributes.position.array);flags.push(flag);g.add(flag);
 }
 // Bowsprit and two triangular headsails establish the sailing silhouette.
 spar(g,V(0,2.8,-8),V(0,5.15,-15.2),.13,timber);
 for(const [z,topY,endZ] of [[-3.5,11.5,-14.8],[-3.5,8.5,-12.8]]){const geo=new T.BufferGeometry().setFromPoints([V(0,topY,z),V(0,4.65,endZ),V(0,4.35,-5.2)]);geo.setIndex([0,1,2]);geo.computeVertexNormals();const sail=new T.Mesh(geo,cloth);g.add(sail);line(g,[[0,topY,z],[0,4.65,endZ],[0,4.35,-5.2]],ghost?'#c34f61':'#81918e',.8);}
 box(g,2.7,.85,2,0,2.76,3.7,timber);box(g,2.92,.13,2.2,0,3.25,3.7,trim);for(let z=2.8;z<4.7;z+=.28)box(g,2.6,.04,.05,0,3.34,z,iron);
 const helm=new T.Group();helm.position.set(0,3.3,-5.8);g.add(helm);helm.add(new T.Mesh(new T.TorusGeometry(.65,.055,8,36),trim));for(let j=0;j<8;j++){const a=j*Math.PI/4;spar(helm,V(0,0,0),V(Math.sin(a)*.83,Math.cos(a)*.83,0),.035,trim);}cylinder(g,.13,.13,1.2,0,2.9,-5.8,timber);
 for(const x of [-2.6,2.6])for(const z of [-6.8,5.8]){
  const carriage=new T.Group();carriage.position.set(x,2.33,z);carriage.rotation.y=x>0?Math.PI/2:-Math.PI/2;g.add(carriage);box(carriage,.62,.25,.9,0,.2,0,mat(ghost?'#3a1b2b':'#8d4c35'));const barrel=cylinder(carriage,.14,.19,1.2,0,.57,-.2,iron);barrel.rotation.x=Math.PI/2;
  for(const xx of [-.38,.38])for(const zz of [-.25,.3]){const wheel=cylinder(carriage,.19,.19,.09,xx,.19,zz,timber);wheel.rotation.z=Math.PI/2;}
 }
 for(const x of [-2.6,2.6])for(const z of [-4.5,1,7]){for(let j=0;j<3;j++){const coil=new T.Mesh(new T.TorusGeometry(.2+j*.06,.023,5,32),trim);coil.rotation.x=-Math.PI/2;coil.position.set(x,2.35,z);g.add(coil);}cylinder(g,.065,.065,.5,x,2.58,z+.5,iron);}
 // Store original opacity: apparition fade scales every material consistently.
 if(ghost)g.traverse((o:any)=>{if(o.isMesh||o.isLine){o.material=o.material.clone();o.material.transparent=true;o.material.depthWrite=false;o.material.userData.baseOpacity=o.isLine?o.material.opacity:o.userData.spectralOpacity??.92;o.castShadow=false;}});
 g.userData.sails=sails;g.userData.flags=flags;g.userData.ghost=ghost;g.userData.helm=helm;return g;
}
export function animateShip(g:T.Group,time:number){
 for(const sail of g.userData.sails??[]){const p=sail.geometry.attributes.position,b=sail.userData.base;for(let i=0;i<p.count;i++){const x=b[i*3],y=b[i*3+1],v=Math.min(1,Math.max(0,(sail.userData.top-y)/sail.userData.height));p.setZ(i,b[i*3+2]+Math.sin(time*1.45+x*.75+sail.userData.phase)*Math.sin(Math.PI*v)*(g.userData.ghost?.15:.075));}p.needsUpdate=true;sail.geometry.computeVertexNormals();}
 for(const flag of g.userData.flags??[]){const p=flag.geometry.attributes.position,b=flag.userData.base;for(let i=0;i<p.count;i++)p.setZ(i,b[i*3+2]+Math.sin(b[i*3]*5-time*4)*Math.min(.22,Math.max(0,b[i*3])*.16));p.needsUpdate=true;flag.geometry.computeVertexNormals();}
}
