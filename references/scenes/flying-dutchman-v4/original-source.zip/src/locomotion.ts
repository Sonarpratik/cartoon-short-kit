/** Metres travelled drive foot phase; cadence never runs independently of travel. */
export const WALK_START=23.5,WALK_DURATION=6.46,WALK_DISTANCE=4.2;
const ramp=.35,clamp=(x:number)=>Math.max(0,Math.min(1,x)),ease=(x:number)=>{const u=clamp(x);return u*u*(3-2*u);};
const integral=(u:number)=>u*u*u-.5*u*u*u*u;
export function midshipmanMotion(time:number,height=2.5){
 const t=Math.max(0,Math.min(WALK_DURATION,time-WALK_START)),speed=WALK_DISTANCE/(WALK_DURATION-ramp);
 const distance=t<ramp?speed*ramp*integral(t/ramp):t>WALK_DURATION-ramp?WALK_DISTANCE-speed*ramp*integral((WALK_DURATION-t)/ramp):speed*(t-ramp/2);
 const blend=ease(t/.28)*ease((WALK_DURATION-t)/.28);
 return {distance,z:-.2-distance,phase:.25+distance/(2*370*.45*height/1000),blend,walking:time>=WALK_START&&time<WALK_START+WALK_DURATION};
}
