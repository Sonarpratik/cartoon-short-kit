import {shotCurve} from '../camera-path';
const camera=(u:number)=>shotCurve(u,[[-1.8,4.2,-.2],[-1,5.4,2.8],[2.3,4.7,3.5],[2.7,4.05,1.5]],[[-1.2,3.55,-3.7],[.5,3.65,-1.8],[.5,3.65,-1.8]],46,38);
export default {id:'S01',start:0,end:150,mode:'night',camera,keys:[{at:0,position:[3.1,4.1,3],target:[.5,3.65,-1.8],fov:38},{at:1,position:[1.9,3.95,1.35],target:[.5,3.7,-1.8],fov:38}]} as const;
