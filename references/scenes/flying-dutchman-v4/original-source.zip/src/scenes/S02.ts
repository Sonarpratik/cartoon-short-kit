import {shotCurve} from '../camera-path';
const camera=(u:number)=>shotCurve(u,[[23,18,25],[24,13,-7],[11,8,-7],[4,5.2,3.5]],[[0,6,0],[0,5,-2],[.5,3.65,-1.8]],49,44);
export default {id:'S02',start:150,end:414,mode:'night',camera,keys:[{at:0,position:[12,14,17],target:[0,5,-1.5],fov:46},{at:.55,position:[7,9,8],target:[.5,4,-1.8],fov:43},{at:1,position:[4,5.5,3.5],target:[.5,3.7,-1.8],fov:42}]} as const;
