import {shotCurve} from '../camera-path';
const camera=(u:number)=>u<.36?shotCurve(u/.36,[[-1.45,4.3,2.8],[-2.4,3.8,2.5],[-1.05,4.28,2.8]],[[-1.45,1.8,-.45],[-1.05,1.8,-.45]],66):shotCurve((u-.36)/.64,[[-1.05,4.28,2.8],[1.7,3.8,2.5],[2.5,4.1,2.7],[-.3,4.25,3.2]],[[-1.05,1.8,-.45],[2.1,1.8,-.45],[0,1.6,-.6]],66,75);
export default {id:'S06',start:1188,end:1550,mode:'cabin',camera,keys:[{at:0,position:[-1.45,4.3,2.8],target:[-1.45,1.8,-.45],fov:66},{at:1,position:[-.3,4.25,3.2],target:[0,1.6,-.6],fov:75}]} as const;
