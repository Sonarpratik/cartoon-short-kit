import {shotCurve,ease} from '../camera-path';
import type {CameraPose} from '../../characters/director';
export function apparitionCamera(u:number):CameraPose{
 if(u<.28)return shotCurve(u/.28,[[4,5.2,3.5],[4,6,6],[-1,5.5,6],[-3,4.8,2]],[[.5,3.65,-1.8],[-10,4,-16],[-22,5,-32]],44,50);
 const v=ease((u-.28)/.72),angle=(29.2-53.2*v)*Math.PI/180,r=38.95-6.95*v;
 return {position:[-22+Math.sin(angle)*r,4.8-2*Math.sin(Math.PI*v)+4*v*v,-32+Math.cos(angle)*r],target:[-22,5+v*.6,-32],fov:50+2*v};
}
export function recallCamera(u:number):CameraPose{const v=ease(u),a=(-18+40*v)*Math.PI/180;return {position:[-22+Math.sin(a)*30,2.7+v*3,-32+Math.cos(a)*30],target:[-22,4.8,-32],fov:53};}
export default {id:'S03',start:414,end:705,mode:'night',camera:apparitionCamera,keys:[{at:0,position:[-5.8,5,-2],target:[-18,5,-25],fov:43},{at:1,position:[-10,6,-6],target:[-19,5.2,-25],fov:42}]} as const;
