import {shotCurve} from '../camera-path';
const camera=(u:number,t:number)=>shotCurve((t-33.44)/(39.6-33.44),[[-7.5,10.5,-.5],[-8,8,5],[-4.8,4.5,6.5],[-2.5,3.35,4.5]],[[0,8,-3.5],[.5,3.4,-1.8],[-.9,2.45,2]],47,40);
export default {id:'S05',start:927,end:1188,mode:'morning',camera,keys:[{at:0,position:[-8,8,-2],target:[0,8,-3.5],fov:43},{at:1,position:[-3.8,4.3,5],target:[-.9,2.5,2],fov:40}]} as const;
