import {glideCamera} from '../../characters/director';
import {midshipmanMotion} from '../locomotion';
import {shotCurve} from '../camera-path';
export function investigationCamera(u:number,t:number){
 const z=midshipmanMotion(t).z;
 if(u<=.65){const pose=shotCurve(u/.65,[[-2.5,4.6,3],[-1.6,6.3,1.5],[-2.2,5.6,-1.7],[-2.8,4.6,-2.9]],[[2.1,3.6,-.2],[2.1,3.6,-3.33]],46,43);pose.target=[2.1,3.6,z];return pose;}
 return shotCurve((u-.65)/.35,[[-2.8,4.6,-2.9],[-3.5,6,-2],[-6,5.9,-3],[-6.3,5.2,-5.5]],[[2.1,3.6,-3.33],[-10,4,-20],[-22,3,-32]],43,49);
}
export default {id:'S04',start:705,end:927,mode:'night',keys:[{at:0,position:[-3.8,4.7,3],target:[.6,3.8,-.2],fov:44},{at:1,position:[-6.3,5.2,-5.5],target:[-18,3,-29],fov:44}]} as const;
