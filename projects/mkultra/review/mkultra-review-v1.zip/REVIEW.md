# Scene review — MKUltra

Narration duration: 34.4555 seconds. 30 fps. Full video not rendered.

| Scene | Time | Words | Version | Status |
|---|---|---|---|---|
| S01 | 0.00–2.50s | The CIA drugged its own citizens… | v1 | to check |
| S02 | 2.50–4.70s | …and they admitted it. | v1 | to check |
| S03 | 4.70–11.70s | Starting in 1953, a secret program called MKUltra tested LSD and other drugs on people. | v1 | to check |
| S04 | 11.70–14.00s | Some of them never knew they'd been dosed. | v1 | to check |
| S05 | 14.00–19.00s | The goal? Mind control… and making people talk under interrogation. | v1 | to check |
| S06 | 19.00–23.40s | In 1973, the CIA director ordered the files destroyed. | v1 | to check |
| S07 | 23.40–28.60s | But about 20,000 documents survived, because they had been misfiled with financial records. | v1 | to check |
| S08 | 28.60–31.60s | They were found in 1977. | v1 | to check |
| S09 | 31.60–34.47s | So… what else do you think got shredded? | v1 | to check |
